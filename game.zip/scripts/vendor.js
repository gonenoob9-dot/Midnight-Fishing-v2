// Copies Three.js into ./vendor (electron-builder strips "examples" folders from node_modules)
const fs = require('fs');
const path = require('path');
const src = path.join(__dirname, '..', 'node_modules', 'three');
const dst = path.join(__dirname, '..', 'vendor', 'three');
fs.rmSync(dst, { recursive: true, force: true });
fs.mkdirSync(path.join(dst, 'build'), { recursive: true });
fs.cpSync(path.join(src, 'build', 'three.module.js'), path.join(dst, 'build', 'three.module.js'));
fs.cpSync(path.join(src, 'examples', 'jsm'), path.join(dst, 'examples', 'jsm'), { recursive: true });
console.log('vendored three ->', dst);
